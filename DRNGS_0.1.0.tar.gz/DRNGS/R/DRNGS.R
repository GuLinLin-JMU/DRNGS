#' @title The structure of identity block in DRNGS.
#' @param data A genotype matrix (N x M; N individuals, M markers)
#' @param ResFrame A list containing the following element for residual network framework.
#' @export
#'
ResNet_block <- function(data, ResFrame)
{
  markerImage <- as.numeric(unlist(strsplit(markerImage,"\\*")))
  block_kernel <- unlist(strsplit(ResFrame$block_kernel,"\\*"))
  block_kernel <- matrix(as.numeric(block_kernel),ncol = 2,byrow = TRUE)
  block_stride <- unlist(strsplit(ResFrame$block_stride,"\\*"))
  block_stride <-  matrix(as.numeric(block_stride),ncol = 2,byrow = TRUE)
  block_pad <- unlist(strsplit(ResFrame$block_pad,"\\*"))
  block_pad <- matrix(as.numeric(block_pad),ncol = 2,byrow = TRUE)
  block_num_filter <- ResFrame$block_num_filter
  block_act_type <- ResFrame$block_act_type
  Conv_1 <- mx.symbol.Convolution(data= data, kernel=block_kernel,stride=block_stride,num_filter= block_num_filter,pad=block_pad)
  Bn_1 <- mx.symbol.BatchNorm(data= Conv_1)
  Act_1 <- mx.symbol.Activation(data= Bn_1, act_type= block_act_type)
  X <- mx.symbol.add_n(data,Act_1,num_args=2)
  X <- mx.symbol.Activation(data= X, act_type= block_act_type)
  return(X)
}
#' @title Build a genomic selection prediction model using the deep residual neural network
#' @description The function applies the deep residual neural network to build a prediction model for genomic selection.
#' @param trainMat A genotype matrix (N x M; N individuals, M markers) for training model.
#' @param trainPheno Vector (N * 1) of phenotype for training model.
#' @param validMat A genotype matrix for validing trained model.
#' @param validPheno Vector (N * 1) of phenotype for validing trained model.
#' @param markerImage  (String) This gives a "i * j" image format that the (M x1) markers informations of each individual will be encoded.
#'                     if the image size exceeds the original SNP number, 0 will be polished the lack part,
#'                     if the image size is less than the original SNP number, the last SNP(s) will be descaled.
#' @param ResFrame  A list containing the following element for residual neural network framework:
#' \itemize{
#'     \item{Res_kernel:} {A vector (K * 1) gives convolutional kernel sizes (width x height) to filter image matrix for K convolutional layers, respectively. }
#'     \item{Res_num_filter:} { A vector (K * 1) gives number of convolutional kernels for K convolutional layers, respectively.}
#'     \item{Res_act_type:} {A vector (K * 1) gives types of active function will define outputs of K convolutional layers which will be an input of corresponding pool layer,
#'           respectively. It include "relu", "sigmoid", "softrelu" and "tanh". }
#'     \item{Res_stride:} {A character (K * 1) strides for K convolutional kernel.}
#'     \item{Respool_type:} {A character (K * 1) types of K pooling layers select from "avg", "max", "sum", respectively.}
#'     \item{Respool_kernel:} {A character (K * 1) K pooling kernel sizes (width * height) for K pooling layers. }
#'     \item{Respool_stride:} {A Character (K * 1) strides for K pooling kernels.}
#'     \item{fullayer_num_hidden:} {A numeric (H * 1) number of hidden neurons for H full connected layers, respectively.
#'           The last full connected layer's number of hidden nerurons must is one.  }
#'     \item{fullayer_act_type:} {A numeric ((H-1) * 1) selecting types of active function from "relu", "sigmoid", "softrelu" and "tanh" for full connected layers.}
#'     \item{drop_float:} {Numeric.}
#' }
#' @param device_type Selecting "CPU" or "GPU" device to  construct predict model.
#' @param gpuNum  (Integer) Number of GPU devices, if using multiple GPU (gpuNum > 1), the parameter momentum must greater than 0.
#' @param eval_metric (String) A approach for evaluating the performance of training process, it include "mae", "rmse" and "accuracy", default "mae".
#' @param num_round (Integer) The number of iterations over training data to train the model, default = 100.
#' @param  array_batch_size (Integer) It defines number of samples that going to be propagated through the network for each update weight, default 30.
#' @param learning_rate  The learn rate for training process.
#' @param momentum  (Float, 0~1) Momentum for moving average, default 0.5.
#' @param wd (Float, 0~1) Weight decay, default 0.00001.
#' @param randomseeds  Set the seed used by mxnet device-specific random number.
#' @param initializer_idx  The initialization scheme for parameters.
#' @param verbose  logical (default=TRUE) Specifies whether to print information on the iterations during training.
#‘
#' @export
#'
#' @examples
#' not run
#' library("DRNGS")
#' data(wheat_example)
#' Markers <- wheat_example$Markers
#' y <- wheat_example$y
#' cvSampleList <- cvSampleIndex(length(y),10,1)
#' cvIdx <- 1
#' trainIdx <- cvSampleList[[cvIdx]]$trainIdx
#' testIdx <- cvSampleList[[cvIdx]]$testIdx
#' trainMat <-Markers[trainIdx,]
#' trainPheno <- y[trainIdx]
#' validIdx <- sample(1:length(trainIdx),floor(length(trainIdx)*0.1))
#' validMat <- trainMat[validIdx,]
#' validPheno <- trainPheno[validIdx]
#' trainMat <- trainMat[-validIdx,]
#' trainPheno <- trainPheno[-validIdx]
#' testMat <- Markers[testIdx,]
#' testPheno <- y[testIdx]
#' Res_kernel <- c("1*18")
#' Res_stride <- c("1*1")
#' Res_num_filter <- c(8)
#' Respool_type <- c("max")
#' Respool_kernel <- c("1*4")
#' Respool_stride <- c("1*4")
#' Res_layer_num <- c(1)
#' Res_act_type <- c("relu")
#' block_kernel <- c("1*17")
#' block_stride <- c("1*1")
#' block_pad <- c("0*8")
#' block_num_filter <- c(8)
#' block_act_type <- c("relu")
#' fullayer_num_hidden <- c(32,1)
#' fullayer_act_type <- c("relu")
#' drop_float <- c(0.2,0.1,0.05)
#' ResFrame <- list(Res_kernel =Res_kernel, Res_stride =Res_stride, Res_num_filter = Res_num_filter,
#'                  Res_act_type = Res_act_type, block_kernel=block_kernel, block_stride=block_stride,
#'                  block_pad=block_pad, block_num_filter=block_num_filter, block_act_type=block_act_type,
#'                  Respool_type=Respool_type,Respool_kernel=Respool_kernel,Respool_stride=Respool_stride,
#'                  fullayer_num_hidden= fullayer_num_hidden,fullayer_act_type = fullayer_act_type,
#'                  drop_float = drop_float,Res_layer_num=Res_layer_num)
#' markerImage = paste0("1*",ncol(trainMat))
#' train_model <- DRNGS(trainMat = trainMat,trainPheno = trainPheno,
#'                 validMat = validMat,validPheno = validPheno,
#'                 markerImage = markerImage, ResFrame = ResFrame,device_type = "gpu",
#'                 gpuNum = 0, eval_metric = "mae",num_round = 100,array_batch_size= 30,
#'                 learning_rate = 0.01,momentum = 0.5,wd = 0.00001, randomseeds = 0,
#'                 initializer_idx = 0.01,verbose = TRUE)
#'
DRNGS <- function(trainMat,trainPheno,validMat,validPheno,markerImage,ResFrame,device_type,gpuNum,
                   eval_metric,num_round ,array_batch_size,learning_rate,momentum ,wd,randomseeds,
                   initializer_idx,verbose =TRUE){
  requireNamespace("mxnet")
  require(mxnet)
  evalfun <- switch(eval_metric,
                    accuracy = mx.metric.accuracy,
                    mae = mx.metric.mae,
                    rmse = mx.metric.rmse)
  if(device_type == "cpu") { device <- mx.cpu()}
  if(device_type == "gpu") { ifelse(gpuNum == "max", device <- mx.gpu(),device <- lapply(0:(gpuNum -1), function(i) {  mx.gpu(i)}))}
  markerImage <- as.numeric(unlist(strsplit(markerImage,"\\*")))
  trainMat <- t(trainMat)
  validMat <- t(validMat)
  dim(trainMat) <- c(markerImage[1], markerImage[2],1,ncol(trainMat))
  dim(validMat) <- c(markerImage[1], markerImage[2],1,ncol(validMat))
  eval.data <- list(data=validMat, label=validPheno)
  Res_kernel <- unlist(strsplit(ResFrame$Res_kernel,"\\*"))
  Res_kernel <- matrix(as.numeric(Res_kernel),ncol = 2,byrow = TRUE)
  Res_stride <- unlist(strsplit(ResFrame$Res_stride,"\\*"))
  Res_stride <-  matrix(as.numeric(Res_stride),ncol = 2,byrow = TRUE)
  Res_num_filter <- ResFrame$Res_num_filter
  Res_act_type <- ResFrame$Res_act_type
  Respool_type <- ResFrame$Respool_type
  Respool_kernel <- unlist(strsplit(ResFrame$Respool_kernel,"\\*"))
  Respool_kernel <- matrix(as.numeric(Respool_kernel),ncol = 2,byrow = TRUE)
  Respool_stride <- unlist(strsplit(ResFrame$Respool_stride,"\\*"))
  Respool_stride <- matrix(as.numeric(Respool_stride),ncol = 2,byrow = TRUE)
  drop_float <- ResFrame$drop_float
  conv_layer_num <- nrow(Res_kernel)
  Res_layer_num <- ResFrame$Res_layer_num
  fullayer_num_hidden <- ResFrame$fullayer_num_hidden
  fullayer_act_type <- ResFrame$fullayer_act_type
  fullayer_num <- length(fullayer_num_hidden)
  data <- mx.symbol.Variable('data')
  for(cc in 1:conv_layer_num){
    if(cc == 1){
      assign(paste0("conv",cc),mx.symbol.Convolution(data= data, kernel=Res_kernel[cc,],stride=Res_stride[cc,], num_filter= Res_num_filter[cc]))
    }else if(cc > 1){
      assign(paste0("conv",cc),mx.symbol.Convolution(data= get(paste0("conv_Act",cc-1)), kernel=Res_kernel[cc,],stride=Res_stride[cc,], num_filter= Res_num_filter[cc]))
    }
    assign(paste0("BN_layer",cc),mx.symbol.BatchNorm(data= get(paste0("conv",cc))))
    assign(paste0("conv_Act",cc), mx.symbol.Activation(data= get(paste0("BN_layer",cc)), act_type= Res_act_type[cc]))
  }
  for(ss in 1:Res_layer_num){
    if(ss == 1){
      assign(paste0("Resblock",ss),ResNet_block(data= get(paste0("conv_Act",conv_layer_num)), ResFrame))
    }else if(ss > 1){
      assign(paste0("Resblock",ss),ResNet_block(data= get(paste0("Resblock",ss-1)), ResFrame))
    }}
  Pool <- mx.symbol.Pooling(data= get(paste0("Resblock",Res_layer_num)), pool_type= Respool_type, kernel= Respool_kernel, stride= Respool_stride)
  drop_initial <- mx.symbol.Dropout(data = Pool,p =drop_float[1])
  fullconnect_initial <- mx.symbol.Flatten(data= drop_initial)
  for(ss in 1:max(c(fullayer_num -1,1))){
    if(ss == 1){
      assign(paste0("fullconnect_layer",ss),mx.symbol.FullyConnected(data= fullconnect_initial, num_hidden= fullayer_num_hidden[ss]))

    } else if(ss > 1){
      assign(paste0("fullconnect_layer",ss),mx.symbol.FullyConnected(data= get(paste0("drop_layer",ss -1)), num_hidden= fullayer_num_hidden[ss]))
    }

    if(fullayer_num == 1){
      assign(paste0("drop_layer",ss),mx.symbol.Dropout(data= get(paste0("fullconnect_layer",ss)), p = drop_float[ss +1]))
    }
    if(fullayer_num > 1){
      assign(paste0("BN_layer",ss),mx.symbol.BatchNorm(data= get(paste0("fullconnect_layer",ss))))
      assign(paste0("fullconnect_Act",ss), mx.symbol.Activation(data= get(paste0("BN_layer",ss)), act_type= fullayer_act_type[ss]))
      assign(paste0("drop_layer",ss),mx.symbol.Dropout(data= get(paste0("fullconnect_Act",ss)), p = drop_float[ss +1]))
    }
  }
  if(fullayer_num > 1){
    assign(paste0("fullconnect_layer",fullayer_num),mx.symbol.FullyConnected(data= get(paste0("drop_layer",ss)), num_hidden= fullayer_num_hidden[fullayer_num]))
    assign(paste0("drop_layer",fullayer_num),mx.symbol.Dropout(data= get(paste0("fullconnect_layer",fullayer_num)), p = drop_float[fullayer_num +1]))
  }
  Resnet_work <- mx.symbol.LinearRegressionOutput(data= get(paste0("drop_layer",fullayer_num)))
  if(!is.null(randomseeds)){mx.set.seed(randomseeds)}
  Res.object <- mx.model.FeedForward.create(Resnet_work, X=trainMat, y=trainPheno,eval.data = eval.data,ctx= device, num.round= num_round,
                                            array.batch.size=array_batch_size,learning.rate=learning_rate, momentum=momentum, wd=wd,
                                            eval.metric= evalfun,initializer = mx.init.uniform(initializer_idx),verbose = verbose,
                                            epoch.end.callback=mx.callback.early.stop(bad.steps = 600,verbose = verbose))
}

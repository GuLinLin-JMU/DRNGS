#' @title Predict GSModel
#' @description Predicting phenotypes from genotypes using DRNGS.
#' @param GSModel Trained prediction model obtained from the DRNGS function.
#' @param testMat  A genotype matrix (T * M; T individuals, M markers)
#' @param markerImage (String) This gives a "i * j" image format that the (M x1) markers informations of each individual will be encoded.
#' @export
predict.DRNGS <- function(GSModel,testMat,markerImage){
  markerImage <- as.numeric(unlist(strsplit(markerImage,"\\*")))
  testMat <- t(testMat)
  dim(testMat) <-  c(markerImage[1], markerImage[2],1,ncol(testMat))
  predict(GSModel,testMat)
}
#' @title Generate Random Seed
#' description This funcation is appplied for generating random seed with current system time
#' (numeric) A random seed
randomSeed <- function() {
  curtime <- format(Sys.time(), "%H:%M:%OS4")
  XXX <- unlist(strsplit(curtime, ":"))
  curtimeidx <- (as.numeric(XXX[1])*3600 + as.numeric(XXX[2])*60 + as.numeric(XXX[3]))*10000
  curtimeidx
}
#' @title Generate Sample Indices for Training Sets and Testing Sets
#' @description  This function generates indices for samples in training and testing sets for performing the N-fold cross validation experiment.
#' @param sampleNum  The number of samples needed to be partitioned into training and testing sets.
#' @param cross  The fold of cross validation.
#' @param seed  An integer used as the seed for data partition. The default value is 1.
#' @param randomSeed  Logical variable. The default value is FALSE.
#' @return
#' A list and each element including $trainIdx, $testIdx and $cvIdx.
#' $trainIdx  The index of training samples.
#' $testIdx   The index of testing samples.
#' $cvIdx     The index of cross validation.
#' @export
#' @examples
#' data(wheat_example)
#' ## 10-fold cross validation
#' s <- cvSampleIndex(sampleNum = 2000, cross = 10, seed = 1)
# get sample idx for training and testing
cvSampleIndex <- function( sampleNum, cross = 5, seed = 1,randomSeed = FALSE ) {
  if(randomSeed == TRUE){
    seed <- randomSeed()
  }
  cv <- cross
  resList <- list()

  # leave-one-out
  if( cv == sampleNum ){
    vec <- 1:sampleNum
    for( i in 1:sampleNum ){
      resList[[i]] <- list( trainIdx = vec[-i], testIdx = i, cvIdx = i)
    }
  }else {
    #random samples
    set.seed(seed)
    index <- sample(1:sampleNum, sampleNum, replace = FALSE )
    step = floor( sampleNum/cv )

    start <- NULL
    end <- NULL
    train_sampleNums <- rep(0, cv)
    for( i in c(1:cv) ) {
      start <- step*(i-1) + 1
      end <- start + step - 1
      if( i == cv )
        end <- sampleNum

      testIdx <- index[start:end]
      trainIdx <- index[-c(start:end)]
      resList[[i]] <- list( trainIdx = trainIdx, testIdx = testIdx, cvIdx = i)
    }
  }
  names(resList) <- paste0("cv",1:cross)
  resList
}

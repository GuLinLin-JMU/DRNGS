#' @name wheat_example
#' @title Run a examples for an in-development function.
#' @description
#' A list including:
#' \itemize{
#' \item{Markers:} {A matrix (599 * 1225), each row represent 1,225 markers information for one individuals.}
#' \item{y:} {The real phenotype value for each individual.}
#' }
#' @docType data
#' @usage data(wheat_example)
NULL
